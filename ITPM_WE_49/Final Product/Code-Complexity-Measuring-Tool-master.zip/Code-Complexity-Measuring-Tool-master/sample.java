class A{
    int a;
    int b;

    int c = a + b;

    for ( int = 0; i < 10; i++ ){
       a = a + 1;
       b = a + b;
    }
}
